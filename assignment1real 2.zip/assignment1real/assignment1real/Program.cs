﻿using System;
using System.Diagnostics;
using Library.assignment1real.Models;

bool cont = true;
var courseList = new List<Course>();   //course list
var studentList = new List<Student>();   //student roster/list
var assignmentList = new List<Assignment>(); //assignment list
var CourseAssignments = new List<Assignment>();

//var courseRoster = new
while (cont)
{
    Console.WriteLine("Please enter in the number associaated with what you would like to do");
    Console.WriteLine("1. Course Creation");
    Console.WriteLine("2. Module Creation");
    Console.WriteLine("3. Content Item Creation");
    Console.WriteLine("4. Student Creation");
    Console.WriteLine("5. Assignment Creation");
    Console.WriteLine("6. Exit");

    var choice = Console.ReadLine() ?? string.Empty;   //returns a string
    if (int.TryParse(choice, out int choiceInt))   //course
    {
        if (choiceInt == 1)
        {
            Console.WriteLine("you chose 1: Course Creation");
            Console.WriteLine("Now, what would you like to do?");
            Console.WriteLine("1. Create a course");
            Console.WriteLine("2. List all the courses");
            Console.WriteLine("3. Update the courses");
            Console.WriteLine("4. Search for course");

            var CourseChoice = int.Parse(Console.ReadLine() ?? "0");
            var newCourse = new Course();
            switch (CourseChoice)
            {
                case 1:     //creating the course
                    Console.WriteLine("Enter a Course Name");
                    newCourse.Name = Console.ReadLine() ?? string.Empty;

                    Console.WriteLine("Enter a Course Code");
                    newCourse.Code = Console.ReadLine() ?? string.Empty;

                    Console.WriteLine("Enter a Course Description");
                    newCourse.Description = Console.ReadLine() ?? string.Empty;

                    //var createdCourse = new Course(/*newCourse*/);
                    courseList.Add(newCourse);

                    break;


                case 2:    //list all the courses 
                    Console.WriteLine("List of the Courses: ");
                    courseList.ForEach(number => Console.WriteLine(number));
                    break;
                ///////
                case 3:    // update the courses  ??????
                    Console.WriteLine("What Course would you like to update? Please input the course code.");
                    courseList.ForEach(number => Console.WriteLine(number));
                    int toDelete;
                    while (!int.TryParse(Console.ReadLine(), out toDelete))
                    {
                        Console.WriteLine("Invalid Selection. Please try again.");
                        courseList.ForEach(number => Console.WriteLine(number));

                        int.TryParse(Console.ReadLine(), out toDelete);
                    }

                    Console.WriteLine("What property do you want to edit?");
                    Console.WriteLine("1. Name");
                    Console.WriteLine("2. Code");
                    Console.WriteLine("3. Description");

                    var indexToDelete = 0;
                    
                    for (int i = 0; i<courseList.Count; i++)
                    {
                        string toDeleteString = toDelete.ToString();
                        if (courseList[i].Code == toDeleteString) //|| courseList[i].Name = toDelete)
                        {

                            indexToDelete = i;
                        }
                        
                    }
                    var updateChoice = int.Parse(Console.ReadLine() ?? "0");
                    switch (updateChoice)
                    {
                        case 1:
                            Console.WriteLine("What is the new Name?");
                            courseList.ElementAt(indexToDelete).Name = Console.ReadLine() ?? string.Empty;
                            break;
                        case 2:
                            Console.WriteLine("What is the new Code?");
                            courseList.ElementAt(indexToDelete).Code = Console.ReadLine() ?? string.Empty;
                            break;
                        case 3:
                            Console.WriteLine("What is the new Description");
                            courseList.ElementAt(indexToDelete).Description = Console.ReadLine() ?? string.Empty;
                            break;
                        default:
                            Console.WriteLine("Sorry, that functionality hasn't been implemented yet!");
                            break;
                    }
                    break;

                case 4:    //searching for a course
                    Console.WriteLine("What course would you like to search for?");
                    var query = Console.ReadLine() ?? string.Empty;

                    var filteredTasks = courseList
                        /*.Where(t =>
                        ((t is Student) || ((t is Student) && (t as Student).IsComplete)) &&
                        (t.Name.Contains(query, StringComparison.InvariantCultureIgnoreCase)
                        || t.LName.Contains(query, StringComparison.InvariantCultureIgnoreCase))
                        );*/
                        .Where(t => (t != null) && (t.Name != null) && t.Name.Contains(query));
                    filteredTasks.ToList().ForEach(task => Console.WriteLine(task));
                    break;

                default:
                    Console.WriteLine("Sorry, that functionality hasn't been implemented yet!");
                    break;
            }
        }
    }

    if (int.TryParse(choice, out int choiceInt2))    //option 2, module
    {
        if (choiceInt2 == 2)
        {
            Console.WriteLine("you chose 2, and we dont have to do this yet!!");
            cont = false;
        }

    }
    if (int.TryParse(choice, out int choiceInt3))    //option 3, content item
    {
        if (choiceInt3 == 3)
        {
            Console.WriteLine("you chose 3, and we dont have to do this yet!!");
            cont = false;
        }

    }
    if (int.TryParse(choice, out int choiceInt4))   //option 4, student
    {
        if (choiceInt4 == 4)
        {
            Console.WriteLine("you chose 4: Student Creation");
            Console.WriteLine("What would you like to do?");
            Console.WriteLine("1. Create a student");
            Console.WriteLine("2. List all students and their courses");
            Console.WriteLine("3. Update student");
            Console.WriteLine("4. Add/remove student to a specific course");   // could this go with 1? do it cohesively??  need to add courses to student
            Console.WriteLine("5. Search for a student");

            // var studentChoice = Console.ReadLine() ?? string.Empty;   //returns a string
            var StudentChoice = int.Parse(Console.ReadLine() ?? "0");
            var newStudent = new Student();
            switch (StudentChoice)
            {
                case 1:
                    Console.WriteLine("Please enter a first name");
                    newStudent.Name = Console.ReadLine() ?? string.Empty;
                    Console.WriteLine("Please enter a last name");
                    newStudent.LName = Console.ReadLine() ?? string.Empty;
                    Console.WriteLine("Please enter their classification (ie.freshman, etc");
                    newStudent.Classification = Console.ReadLine() ?? string.Empty;

                    //var createdStudent = new Course(newStudent);
                    studentList.Add(newStudent);
                    break;

                case 2:

                    Console.WriteLine("List of the Student: ");
                    studentList.ForEach(number => Console.WriteLine(number));

                    /////////////////////////
                    Console.WriteLine("Which student would you like to see the courses of? Please enter in last name.");
                    var optionStudentChoice = Console.ReadLine() ?? string.Empty;
                    Console.WriteLine("These are the students course:");
                    int indexStudentList = 0;
                    var whichStudent = new ContentItem();
                    for (int i = 0; i < studentList.Count; i++)
                    {
                        //string whichStudentString = whichStudent.LName;
                        if (optionStudentChoice == studentList[i].LName)
                        {
                            indexStudentList = i;
                            courseList.ForEach(number => Console.WriteLine(number));
                        }
                    }
                    break;

                case 3:   //update the student

                    Console.WriteLine("What aspect of the student would you like to update? Please enter in last name.");
                    studentList.ForEach(number => Console.WriteLine(number));
                    int toDelete;
                    while (!int.TryParse(Console.ReadLine(), out toDelete))
                    {
                        Console.WriteLine("Invalid Selection. Please try again.");
                        studentList.ForEach(number => Console.WriteLine(number));

                        int.TryParse(Console.ReadLine(), out toDelete);
                    }

                    Console.WriteLine("What property do you want to edit?");
                    Console.WriteLine("1. Name");
                    Console.WriteLine("2. Last Name");
                    Console.WriteLine("3. Classification");

                    var indexToDelete = 0;

                    for (int i = 0; i < courseList.Count; i++)
                    {
                        string toDeleteString = toDelete.ToString();
                        if (studentList[i].LName == toDeleteString)// studentList[i].Name = toDelete)
                        {

                            indexToDelete = i;
                        }

                    }
                    var updateChoice = int.Parse(Console.ReadLine() ?? "0");
                    switch (updateChoice)
                    {
                        case 1:
                            Console.WriteLine("What is the new Name?");
                            studentList.ElementAt(indexToDelete).Name = Console.ReadLine() ?? string.Empty;
                            break;
                        case 2:
                            Console.WriteLine("What is the new Code?");
                            studentList.ElementAt(indexToDelete).LName = Console.ReadLine() ?? string.Empty;
                            break;
                        case 3:
                            Console.WriteLine("What is the new Classification");
                            studentList.ElementAt(indexToDelete).Classification = Console.ReadLine() ?? string.Empty;
                            break;
                        default:
                            Console.WriteLine("Sorry, that functionality hasn't been implemented yet!");
                            break;
                    }
                    //break;
                    break;

                case 4:

                    Console.WriteLine("Would you like to add or remove a student from a course?");
                    Console.WriteLine("1. Add student to a course");
                    Console.WriteLine("2. Remove a student from a course");
                    var optionStudentChoice1 = Console.ReadLine() ?? string.Empty;
                    var whichCourse = new Course();
                    var whichhStudent = new Student();
                    if (int.TryParse(optionStudentChoice1, out int optionStudent11))
                    {
                        if (optionStudent11 == 1)
                        {
                            Console.WriteLine("What student would you like to add to a course? Please enter in first name");
                            studentList.ForEach(number => Console.WriteLine(number));
                            whichhStudent.Name = Console.ReadLine() ?? string.Empty;

                            Console.WriteLine("What course would you like to add the student to? Please enter in the code");
                            courseList.ForEach(number => Console.WriteLine(number));
                            whichCourse.Code = Console.ReadLine() ?? string.Empty;
                            int newStudentCourseRosterIndex = 0;
                            for (int i = 0; i < courseList.Count; i++)
                            {
                                //string whichStudentString = whichStudent.Name;
                                string whichCourseString = whichCourse.Code;
                                if (whichCourseString == courseList[i].Code)
                                {
                                    newStudentCourseRosterIndex = i;
                                    courseList[newStudentCourseRosterIndex].Roster.Add((Student)whichhStudent);
                                }
                            }


                        }
                        if (optionStudent11 == 2)
                        {
                            Console.WriteLine("What course would you like to edit the roster. Please enter in the code");
                            courseList.ForEach(number => Console.WriteLine(number));
                            whichCourse.Code = Console.ReadLine() ?? string.Empty;

                            Console.WriteLine("What student would you like to remove from this course? Please enter in last name");
                            studentList.ForEach(number => Console.WriteLine(number));
                            whichhStudent.LName = Console.ReadLine() ?? string.Empty;
                            int newStudentCourseRosterIndex = 0;
                            for (int i = 0; i < courseList.Count; i++)
                            {
                                //string whichStudentString = whichStudent.Name;
                                string whichCourseString = whichCourse.Code;
                                if (whichCourseString == courseList[i].Code)
                                {
                                    newStudentCourseRosterIndex = i;
                                    courseList[newStudentCourseRosterIndex].Roster.Remove((Student)whichhStudent);
                                }
                            }

                        }
                    }

                    break;
                ////////////////////////////////////////////////////////////
                case 5:

                    Console.WriteLine("What student would you like to search for?");
                    var query = Console.ReadLine() ??string.Empty;

                    var filteredTasks = studentList
                        /*.Where(t =>
                        ((t is Student) || ((t is Student) && (t as Student).IsComplete)) &&
                        (t.Name.Contains(query, StringComparison.InvariantCultureIgnoreCase)
                        || t.LName.Contains(query, StringComparison.InvariantCultureIgnoreCase))
                        );*/
                        .Where(t => (t != null) && (t.Name != null) && t.Name.Contains(query));
                    filteredTasks.ToList().ForEach(task => Console.WriteLine(task));
                    break;
            }

        }
    }
    if (int.TryParse(choice, out int choiceInt5))   //option 5, assignment
    {
        if (choiceInt == 5)
        {
            var newAssignment = new Assignment();
            Console.WriteLine("you chose 5: Assignment Creation");
            Console.WriteLine("Please input an Assignment Name");

            newAssignment.Name = Console.ReadLine() ?? string.Empty;   //read in assigment name

            Console.WriteLine("Please input the Total Available Points");
            newAssignment.TotalAvailablePoints = Console.ReadLine() ?? string.Empty;

            Console.WriteLine("Please input the Due Date");
            newAssignment.DueDate = Console.ReadLine() ?? string.Empty;

            Console.WriteLine("Please input the Description");
            newAssignment.Description = Console.ReadLine() ?? string.Empty;

            var createdAssignment = new Assignment(/*newAssignment*/);
            assignmentList.Add(createdAssignment);

            //need to add assignment to a specific  course
            Console.WriteLine("List of the Courses: ");
            courseList.ForEach(number => Console.WriteLine(number));

            Console.WriteLine("Which course do you want to add the assignment to? Please enter the name");
            courseList.ForEach(number => Console.WriteLine(number));


            var assignmentToCourse = new Assignment();
            assignmentToCourse.Name = Console.ReadLine() ?? string.Empty;
            int newAssignmentCourseIndex = 0;
            for (int i = 0; i < courseList.Count; i++)
            {
                string assignmentToCourseString = assignmentToCourse.Name;
                if(assignmentToCourseString == courseList[i].Name)
                {
                   newAssignmentCourseIndex = i;
                   courseList[newAssignmentCourseIndex].CourseAssignments.Add(createdAssignment);
                }
            }

        }

    }
    if (int.TryParse(choice, out int choiceInt6))   //option 6, exit
    {
        if (choiceInt == 6)
        {
            Console.WriteLine("exit");
            cont = false;
        }

    }
}
