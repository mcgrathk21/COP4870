﻿using System;
namespace Library.assignment1real.Models
{
	public class Module :ContentItem
	{

        public List<ContentItem> Content { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public Module()
		{
            Content = new List<ContentItem>();
        }


    }
}

