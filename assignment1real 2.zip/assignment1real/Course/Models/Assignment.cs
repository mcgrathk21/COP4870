﻿using System;
namespace Library.assignment1real.Models


	//add on total available point and due date
{
	public class Assignment 
	{

       public string? Name { get; set; }
       public string? Description { get; set; }
       public string? DueDate { get; set; }
       public string? TotalAvailablePoints { get; set; }

        public Assignment()
		{
		}

		//public Assignment(ContentItem i)
		//{
		//	Name = i.Name;
		//	Description = i.Description;
		//	DueDate = i.DueDate;
		//	TotalAvailablePoints = i.TotalAvailablePoints;
		//}

	}
}

