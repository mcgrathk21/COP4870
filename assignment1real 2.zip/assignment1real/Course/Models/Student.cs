﻿using System;
namespace Library.assignment1real.Models
{
	public class Student 

	{
       public string? LName { get; set; }
       public string? Classification { get; set; }
       public string? Grades { get; set; }
       public string? Name { get; set; }
        public Student()
		{

		}

        
        public virtual string StudentDisplay => $"{Name} {LName}({Classification})";

  //      public Student(ContentItem i)
		//{
		//	Name = i.Name;
		//	LName = i.LName;
		//	Classification = i.Classification;
		//	Grades = i.Grades;
		//}

        public bool IsComplete { get; set; }
        public override string ToString()
        {
            return StudentDisplay;
        }
    }
}

