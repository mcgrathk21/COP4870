﻿
using System;
using System.Xml.Linq;

namespace Library.assignment1real.Models
{
    public class Course //: ContentItem
    {
        public bool IsComplete { get; set; }

        public List<Assignment> CourseAssignments { get; set; }
        public List<Student> Roster { get; set; }
        public List<Module> Modules { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
       public string? Description { get; set; }
        public Course()

        {
            Code = string.Empty;
            Name = string.Empty;
            Description = string.Empty;
            CourseAssignments = new List<Assignment>();
            Roster = new List<Student>();
            Modules = new List<Module>();
        }
        public string Display => $"{Name}({Code})";

        //public Course(ContentItem i)
        //{
        //    Name = i.Name;
        //    Description = i.Description;
        //    Code = i.Code;

        //    CourseAssignments = new List<Assignment>();
        //    Roster = new List<Student>();
        //    Modules = new List<Module>();
        //}

        public override string ToString()
        {
            return Display;
        }
    }
}