﻿using System;
namespace Library.assignment1real.Models
{
	public class ContentItem
    { 
       
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Path { get; set; }

    }
}

